<?php
return array(
    'addText' => '',
    'removeText' => '',
    'value' => '',
    'tpl' => 'cl.addToCookieList',
);