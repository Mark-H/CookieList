<?php

$_lang['cookielist'] = 'CookieList';
$_lang['cookielist.add_text'] = 'Add to your CookieList';
$_lang['cookielist.remove_text'] = 'Remove from your CookieList';
$_lang['cookielist.err.no_cookies'] = 'It seems your browser is not set up to allow Cookies, and because of that it is not possible to use this functionality. <a href="http://www.google.com/support/accounts/bin/answer.py?answer=61416" title="Read instructions on enabling Cookies">Learn how to enable Cookies.</a>';

?>