<?php
return [
    'addText' => '',
    'removeText' => '',
    'value' => '',
    'tpl' => 'cl.addToCookieList',
];
