<?php

$_lang['cookielist'] = 'CookieList';
$_lang['cookielist.add_text'] = 'Ajouter à votre liste';
$_lang['cookielist.remove_text'] = 'Retirer de votre liste';
$_lang['cookielist.err.no_cookies'] = 'Il semblerait que votre navigateur ne soit pas configuré pour utiliser les cookies. Vous ne pouvez donc pas utiliser cette fonction. <a href="http://www.google.com/support/accounts/bin/answer.py?answer=61416" title="Lire les instructions pour activer l\'utilisation des cookies">Documenation pour activer l\'utilisation des cookies.</a>';

?>